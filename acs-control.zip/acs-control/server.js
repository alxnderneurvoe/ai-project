/*
  ACS Control - Backend
  ----------------------
  Jembatan antara web dashboard dan Hikvision Access Control Terminal (ISAPI).

  Kenapa perlu backend (bukan langsung dari browser)?
  - Device Hikvision butuh Digest Authentication, browser JavaScript (fetch)
    tidak bisa handle ini dengan mudah/aman.
  - Kredensial device (username/password) tidak boleh terekspos ke browser
    pengguna - harus disimpan di server saja.

  Environment variables yang WAJIB diisi (lihat docker-compose.yml):
    HIKVISION_IP    - IP address device, contoh: 10.90.0.70
    HIKVISION_USER  - username admin device
    HIKVISION_PASS  - password admin device
    DOOR_NO         - nomor pintu, biasanya 1 (cek dokumentasi device kalau ada beberapa pintu)
*/

const express = require('express');
const DigestFetch = require('digest-fetch');

const app = express();
const PORT = 3000;

const HIKVISION_IP = process.env.HIKVISION_IP;
const HIKVISION_USER = process.env.HIKVISION_USER;
const HIKVISION_PASS = process.env.HIKVISION_PASS;
const DOOR_NO = process.env.DOOR_NO || '1';

if (!HIKVISION_IP || !HIKVISION_USER || !HIKVISION_PASS) {
  console.error('ERROR: HIKVISION_IP, HIKVISION_USER, dan HIKVISION_PASS wajib diisi di environment variables.');
  process.exit(1);
}

const client = new DigestFetch(HIKVISION_USER, HIKVISION_PASS);

// Log aktivitas disimpan di memory (hilang kalau container restart - untuk log permanen,
// bisa disambungkan ke database atau file nanti kalau perlu).
const MAX_LOG = 50;
let activityLog = [];

function addLog(action, email, success, detail) {
  activityLog.unshift({
    action,
    email: email || 'unknown (akses tanpa Cloudflare Access)',
    success,
    detail: detail || '',
    timestamp: new Date().toISOString(),
  });
  if (activityLog.length > MAX_LOG) activityLog.pop();
}

async function sendDoorCommand(cmd) {
  const url = `http://${HIKVISION_IP}/ISAPI/AccessControl/RemoteControl/door/${DOOR_NO}`;
  const body = `<RemoteControlDoor version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><cmd>${cmd}</cmd></RemoteControlDoor>`;

  const response = await client.fetch(url, {
    method: 'PUT',
    body,
    headers: { 'Content-Type': 'application/xml' },
  });

  const text = await response.text();

  if (!response.ok) {
    throw new Error(`Device merespons status ${response.status}: ${text}`);
  }

  return text;
}

app.use(express.static('public'));
app.use(express.json());

// Cloudflare Access menyisipkan header ini otomatis kalau request lewat Access -
// dipakai untuk mencatat SIAPA yang melakukan aksi, tanpa perlu bikin sistem login sendiri.
function getAuthenticatedEmail(req) {
  return req.headers['cf-access-authenticated-user-email'] || null;
}

app.post('/api/door/open', async (req, res) => {
  const email = getAuthenticatedEmail(req);
  try {
    await sendDoorCommand('open');
    addLog('OPEN', email, true);
    res.json({ success: true, message: 'Pintu berhasil dibuka' });
  } catch (err) {
    addLog('OPEN', email, false, err.message);
    console.error('Gagal buka pintu:', err.message);
    res.status(502).json({ success: false, message: 'Gagal mengirim command ke device: ' + err.message });
  }
});

app.post('/api/door/close', async (req, res) => {
  const email = getAuthenticatedEmail(req);
  try {
    await sendDoorCommand('close');
    addLog('CLOSE', email, true);
    res.json({ success: true, message: 'Pintu berhasil ditutup' });
  } catch (err) {
    addLog('CLOSE', email, false, err.message);
    console.error('Gagal tutup pintu:', err.message);
    res.status(502).json({ success: false, message: 'Gagal mengirim command ke device: ' + err.message });
  }
});

app.get('/api/log', (req, res) => {
  res.json({ log: activityLog });
});

app.get('/api/whoami', (req, res) => {
  res.json({ email: getAuthenticatedEmail(req) });
});

app.listen(PORT, () => {
  console.log(`ACS Control backend jalan di port ${PORT}`);
  console.log(`Target device: ${HIKVISION_IP}, door ${DOOR_NO}`);
});
